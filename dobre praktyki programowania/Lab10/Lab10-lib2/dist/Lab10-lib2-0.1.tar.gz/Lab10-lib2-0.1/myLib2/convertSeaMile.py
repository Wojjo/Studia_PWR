def sea_mile_to_km(miles):
    km = miles*1.852
    return km