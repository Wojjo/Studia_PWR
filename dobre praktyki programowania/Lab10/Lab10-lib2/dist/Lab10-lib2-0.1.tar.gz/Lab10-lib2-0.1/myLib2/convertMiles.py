def mile_to_km(mile):
    km = mile*1.609
    return km
