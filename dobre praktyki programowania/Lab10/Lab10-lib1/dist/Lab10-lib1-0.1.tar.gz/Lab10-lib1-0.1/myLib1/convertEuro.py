
def euro_to_pln(money):
    pln = money*4.30
    return pln
