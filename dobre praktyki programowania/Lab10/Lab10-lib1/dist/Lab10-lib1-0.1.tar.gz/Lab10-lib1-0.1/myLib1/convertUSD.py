
def euro_to_pln(money):
    pln = money*3.84
    return pln
